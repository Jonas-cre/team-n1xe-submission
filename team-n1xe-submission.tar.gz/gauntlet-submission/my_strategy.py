"""Team strategy for team-n1xe."""

from __future__ import annotations

from base_strategy import BaseStrategy


class MyStrategy(BaseStrategy):
    """Team N1XE competitor strategy."""

    agent_id = "team-n1xe"
    agent_name = "Team N1XE"

    # Text challenges (logic, reasoning, retrieval, structured output)
    text_system_prompt = ("You are a fast, precise puzzle solver. Time is very limited. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Think briefly, commit to an answer quickly, and do not re-verify "
        "more than once. If the task specifies an output format, match it "
        "exactly inside the ANSWER line with no extra words. "
        "Never output 'unknown'. Do not output <think> tags. "
        "After the ANSWER line, add at most 1 short line of justification."
    )
    text_strategy_notes = (
        "Be fast. Commit to an answer quickly. Always start with the ANSWER line."
    )
    text_temperature = 0.0
    text_max_tokens = 8192

    # Image challenges (edit a given image, or generate one)
    image_strategy_notes = (
        "Prefer image_edit when an input image is available. Change only what the "
        "task asks for and name the exact color, object, and position. Explicitly "
        "preserve facial features, camera angle, lighting, and background. Avoid "
        "heavy style transfer. Request standard-resolution output only and avoid "
        "HD or 4K images. Keep rationale concise."
    )